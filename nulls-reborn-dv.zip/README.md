# nulls-reborn-dv
Pack based on [nulls-reborn](https://github.com/BlendyDev/nulls-reborn)

Continuation of the Nulls Reborn Hypixel Skyblock texture pack for glitch items.

## New features
- Damage value indicators for every null block that would otherwise have the same texture
- Textures for null slabs (STEP and WOOD_STEP)
- Custom textures for null bow and fishing rod
- 1.7 textures for Water/Lava/Water (No Spread)/Lava (No Spread)
- Textures for placed alpha slab (similar to the item texture provided by the original version of the pack)
- Null map texture
- Null sapling texture
- Updated icon with correct openGL untextured pink

## Credits
FaasNax, Zeroing, SpikeRox, Shy0 for making [Nulls Reborn v2](https://hypixel.net/threads/nulls-reborn-2-0-1-8-9-null-texture-pack.4175552/)
